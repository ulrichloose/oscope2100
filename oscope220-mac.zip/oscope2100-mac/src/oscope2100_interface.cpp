#include "oscope2100_common.h"
#include "oscope2100_interface.h"
#include "oscope2100_usb.h"

#include <iostream>
#include <fstream>
#include <gtk/gtk.h>
#include <math.h>
#include <stdlib.h>

tcapture_mode capture_mode;
gboolean restart_capture;

// UI state
tmode ui_mode;
int ui_time;

int tr_pos=127;
int tr_pos1=127;
int ch1_pos=0;
int ch2_pos=0;
int s_ch1_pos=0;
int s_ch2_pos=0;

gboolean ui_ch1_on;
int ui_ch1_voltage;
tchmode ui_ch1_mode;
tchmul ui_ch1_mul;

gboolean ui_ch2_on;
int ui_ch2_voltage;
tchmode ui_ch2_mode;
tchmul ui_ch2_mul;

ttrigger ui_trigger;
int ui_edge;

int ui_s_trig=0;
int ui_s_trig1=0;

const char* Sample[21] = {"60MS/s","60MS/s","60MS/s","60MS/s","60MS/s","60MS/s","60MS/s","60MS/s","30MS/s","10MS/s","5MS/s","2.5MS/s","1MS/s","500KS/s","250KS/s","100KS/s","50KS/s","25KS/s","10KS/s","5KS/s","2.5KS/s"};

const char* Stime[21] = {"100nS","250nS","500nS","1uS","2.5uS","5uS","10uS","25uS","50uS","100uS","250uS","500uS","1mS","2.5mS","5mS","10mS","25mS","50mS","100mS","250mS","500mS"};

const float Ttime[21] = {0.0000001,0.00000025,0.0000005,0.000001,0.0000025,0.000005,0.00001,0.000025,0.00005,0.0001,0.00025,0.0005,0.001,0.0025,0.005,0.01,0.025,0.05,0.1,0.25,0.5};

gboolean ui_scientific_format;
uchar ui_separator;

std::ostringstream expstr;

GtkWidget *window;
GtkWidget *hscale;
GtkWidget *hscale1;
GtkWidget *vscale;
GtkWidget *vscale1;
GdkPixmap *scopebg; // black scope background + divs
GtkWidget *draw_area;
//
GtkWidget *ch1_label;
GtkWidget *ch2_label;
GtkWidget *time_label;
GtkWidget *sample_label;
GtkWidget *x_info_label;
GtkWidget *y_info_label;
GtkWidget *demo_label;
//
GtkWidget *s_trig;
GtkWidget *ch1_on;
GtkWidget *ch1_voltage;
GtkWidget *ch1_mode;
GtkWidget *ch1_mul;
//
GtkWidget *ch2_on;
GtkWidget *ch2_voltage;
GtkWidget *ch2_mode;
GtkWidget *ch2_mul;
//
GtkWidget *cb_time;
//
GtkWidget *cb_mode;
//
GtkWidget *cb_trigger;
GtkWidget *cb_edge;

int cursor_x0;
int cursor_y0;
int cursor_x1;
int cursor_y1;

// data buffer and params for GUI
uchar ch1buf[BUFSIZE];
uchar ch2buf[BUFSIZE];
int buf_time;
int buf_ch1;
int buf_ch2;

double ch1_k; // 1, 10, 100
double ch2_k; // 1, 10, 100

bool destroying=false;

gboolean on_draw_area_resize(GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  //remove cursor
  cursor_x0=-1;
  cursor_y0=-1;
  cursor_x1=-1;
  cursor_y1=-1;
  gtk_widget_hide(x_info_label);
  gtk_widget_hide(y_info_label);
  //redraw scopebg
  int w=576;
  int h=384;
  //
  if (scopebg!=NULL) g_object_unref(scopebg);
  scopebg = gdk_pixmap_new(NULL, w, h, gdk_colormap_get_visual(gdk_colormap_get_system())->depth);
  //std::cout<<"New Windows area size is "<<window->allocation.width<<" x "<<window->allocation.height<<std::endl;
  //draw background
  GdkGC *gc = gdk_gc_new (widget->window);
  //
  GdkColor color = {0xffff,0x0000,0x0000,0x0000};
  gdk_colormap_alloc_color (gdk_colormap_get_system (),&color, FALSE, TRUE);
  gdk_gc_set_foreground(gc,&color);
	//
  gdk_draw_rectangle (scopebg,gc,TRUE,0,0,w,h);
  // draw divs
  color.red=0x9900;
  color.green=0x3300;
  color.blue=0x3300;
  gdk_colormap_alloc_color (gdk_colormap_get_system (),&color, FALSE, TRUE);
  gdk_gc_set_foreground(gc,&color);
  //
    gdk_draw_rectangle (scopebg,gc,FALSE,0,0,w-1,h-1);
    gdk_draw_line(scopebg,gc,0,(h/2),w-1,(h/2));
    gdk_draw_line(scopebg,gc,(w/2),0,(w/2),h-1);
    
    for (int n=1;n<=11;n++)
    {
      int x=(n*w)/12;
      for (int y=1;y<=h;y+=4) gdk_draw_point(scopebg,gc,x,y);
    }
    for (int n=1;n<=7;n++)
    {
      int y=(n*h)/8;
      for (int x=1;x<=w;x+=4) gdk_draw_point(scopebg,gc,x,y);
    }
    for (int n=1;n<=47;n++)
    {
      int x=(n*w)/48;
      gdk_draw_point(scopebg,gc,x,1);
      gdk_draw_point(scopebg,gc,x,2);
      //
      gdk_draw_point(scopebg,gc,x,(h/2)-2);
      gdk_draw_point(scopebg,gc,x,(h/2)-1);
      gdk_draw_point(scopebg,gc,x,(h/2)+0);
      gdk_draw_point(scopebg,gc,x,(h/2)+1);
      gdk_draw_point(scopebg,gc,x,(h/2)+2);
      //
      gdk_draw_point(scopebg,gc,x,h-3);
      gdk_draw_point(scopebg,gc,x,h-2);
    }
    for (int n=1;n<=31;n++)
    {
      int y=((n*h)/32);
      gdk_draw_point(scopebg,gc,1,y);
      gdk_draw_point(scopebg,gc,2,y);
      //
      gdk_draw_point(scopebg,gc,(w/2)-2,y);
      gdk_draw_point(scopebg,gc,(w/2)-1,y);
      gdk_draw_point(scopebg,gc,(w/2)+0,y);
      gdk_draw_point(scopebg,gc,(w/2)+1,y);
      gdk_draw_point(scopebg,gc,(w/2)+2,y);
      //
      gdk_draw_point(scopebg,gc,w-3,y);
      gdk_draw_point(scopebg,gc,w-2,y);
    }
  return TRUE;
}

gboolean on_draw_area_expose (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  GdkGC *gc = gdk_gc_new (widget->window);
  GdkColor color;
  //
  gdk_draw_drawable (widget->window,gc,scopebg,0,0,0,0,-1,-1);
  //
  int w=576;
  int h=384;
  int miny0;
  int maxy0;
  int miny1;
  int maxy1;
  int x0;
  int p0,p1;
  int p_start=0;
  //
    if (ui_ch1_on)
    {
      // Draw CH1
      color.red   = 0x0000;
      color.green = 0xFFFF;
      color.blue  = 0x0000;
      gdk_colormap_alloc_color (gdk_colormap_get_system (),&color, FALSE, TRUE);
      gdk_gc_set_foreground (gc, &color);
      //
      miny0=-1;
      maxy0=-1;
      miny1=-1;
      maxy1=-1;
      x0=0;
      int pos=0;
      
      if (tr_pos > 77) ui_s_trig=1; else ui_s_trig=0;
      
      if (ui_s_trig == 1 && (ui_trigger == TR_CH1 || ui_trigger == TR_ALT))
      {
      
        // Ignore trigger right now - we need to get untriggered first
        
        pos = 8;
        while ((((ch1buf[pos-2] + ch1buf[pos-1] + ch1buf[pos] + ch1buf[pos+1] + ch1buf[pos+2])/5) >= tr_pos and ui_edge == 0) || (((ch1buf[pos-2] + ch1buf[pos-1] + ch1buf[pos] + ch1buf[pos+1] + ch1buf[pos+2])/5) <= tr_pos and ui_edge == 1))
        {
          pos ++;
        }
        
        // Now - wait for a trigger state to come back to trigger level
        
        if (pos <= BUFSIZE/4)
        {
          while ((((ch1buf[pos-2] + ch1buf[pos-1] + ch1buf[pos] + ch1buf[pos+1] + ch1buf[pos+2])/5) <= tr_pos and ((ch1buf[pos-1] + ch1buf[pos] + ch1buf[pos+1] + ch1buf[pos+2] + ch1buf[pos+3])/5) <= tr_pos and ui_edge == 0) || (((ch1buf[pos-2] + ch1buf[pos-1] + ch1buf[pos] + ch1buf[pos+1] + ch1buf[pos+2])/5) >= tr_pos and ((ch1buf[pos-1] + ch1buf[pos] + ch1buf[pos+1] + ch1buf[pos+2] + ch1buf[pos+3])/5) >= tr_pos and ui_edge == 1))
          {
            pos ++;
            if (pos >= BUFSIZE/3)
            {
              pos = 0;
              break;
            }
          }
        }
        else
        {
          pos=0;
        }
      }
      
      //std::cout<<pos<<std::endl;
      
      for (int x=0;x<w;x++)
      {
        p0=(x*BUFSIZE/Pteil[buf_time])/480+pos;
        p1=((x+1)*BUFSIZE/Pteil[buf_time])/480+pos;

        miny1=-1;
        maxy1=-1;
        
        for (int p=p0;p<p1;p++)
        {
          if ((miny1==-1) || (ch1buf[p]<miny1)) miny1=ch1buf[p];
          if ((maxy1==-1) || (ch1buf[p]>maxy1)) maxy1=ch1buf[p];
        }
        
        if ((miny0!=-1) && (maxy0!=-1) && (miny1!=-1) && (maxy1!=-1))
        {
          int min_y0=(h*(0xff-miny0))/0x100;
          int min_y1=(h*(0xff-miny1))/0x100;
          int max_y0=(h*(0xff-maxy0))/0x100;
          int max_y1=(h*(0xff-maxy1))/0x100;
          int y0=min_y0+(max_y0 - min_y0)/2+ch1_pos;
          int y1=min_y1+(max_y1 - min_y1)/2+ch1_pos;
          gdk_draw_line(draw_area->window,gc,x0,y0,x,y1);
          x0=x;
        }
        if (miny1!=-1) miny0=miny1;
        if (maxy1!=-1) maxy0=maxy1;
      }
    }
    
    if (ui_ch2_on)
    {
      // Draw CH2 ...
      color.red   = 0xffff;
      color.green = 0xffff;
      color.blue  = 0x0000;
      //
      gdk_colormap_alloc_color (gdk_colormap_get_system (),&color, FALSE, TRUE);
      gdk_gc_set_foreground (gc, &color);
      //
      miny0=-1;
      maxy0=-1;
      miny1=-1;
      maxy1=-1;
      x0=0;
      int pos=0;
      
      if (tr_pos1 > 77) ui_s_trig1=1; else ui_s_trig1=0;
      
      if (ui_s_trig1 == 1 && (ui_trigger == TR_CH2 || ui_trigger == TR_ALT))
      {
        
        // Ignore trigger right now - we need to get untriggered first
      
        pos = 8;
        while ((((ch2buf[pos-2] + ch2buf[pos-1] + ch2buf[pos] + ch2buf[pos+1] + ch2buf[pos+2])/5) >= tr_pos1 and ui_edge == 0) || (((ch2buf[pos-2] + ch2buf[pos-1] + ch2buf[pos] + ch2buf[pos+1] + ch2buf[pos+2])/5) <= tr_pos1 and ui_edge == 1))
        {
          pos ++;
        }
        
        // Now - wait for a trigger state to come back to trigger level
        
        if (pos <= BUFSIZE/4)
        {
          while ((((ch2buf[pos-2] + ch2buf[pos-1] + ch2buf[pos] + ch2buf[pos+1] + ch2buf[pos+2])/5) <= tr_pos1 and ((ch2buf[pos-1] + ch2buf[pos] + ch2buf[pos+1] + ch2buf[pos+2] + ch2buf[pos+3])/5) <= tr_pos1 and ui_edge == 0) || (((ch2buf[pos-2] + ch2buf[pos-1] + ch2buf[pos] + ch2buf[pos+1] + ch2buf[pos+2])/5) >= tr_pos1 and ((ch2buf[pos-1] + ch2buf[pos] + ch2buf[pos+1] + ch2buf[pos+2] + ch2buf[pos+3])/5) >= tr_pos1 and ui_edge == 1))
          {
            pos ++;
            if (pos >= BUFSIZE/3)
            {
              pos = 0;
              break;
            }
          }
        }
        else
        {
          pos=0;
        }
      }

      for (int x=0;x<w;x++)
      {
        p0=(x*BUFSIZE/Pteil[buf_time])/480+pos;
        p1=((x+1)*BUFSIZE/Pteil[buf_time])/480+pos;
        miny1=-1;
        maxy1=-1;
        
        for (int p=p0;p<p1;p++)
        {
          if ((miny1==-1) || (ch2buf[p]<miny1)) miny1=ch2buf[p];
          if ((maxy1==-1) || (ch2buf[p]>maxy1)) maxy1=ch2buf[p];
        }
          
        // draw lines
        if ((miny0!=-1) && (maxy0!=-1) && (miny1!=-1) && (maxy1!=-1))
        {
          int min_y0=(h*(0xff-miny0))/0x100;
          int min_y1=(h*(0xff-miny1))/0x100;
          int max_y0=(h*(0xff-maxy0))/0x100;
          int max_y1=(h*(0xff-maxy1))/0x100;
          int y0=min_y0+(max_y0 - min_y0)/2+ch2_pos;
          int y1=min_y1+(max_y1 - min_y1)/2+ch2_pos;
          gdk_draw_line(draw_area->window,gc,x0,y0,x,y1);
          x0=x;
        }
        if (miny1!=-1) miny0=miny1;
        if (maxy1!=-1) maxy0=maxy1;
      }
  }
  // cursor
  if ((cursor_x0>=0) && (cursor_x1>=0) && (cursor_y0>=0) && (cursor_y1>=0))
  {
    color.red   = 0xffff;
    color.green = 0x4000;
    color.blue  = 0xffff;
    //
    gdk_colormap_alloc_color (gdk_colormap_get_system (),&color, FALSE, TRUE);
    gdk_gc_set_foreground (gc, &color);
    //
    if (cursor_x0<w)
    {
      for (int y=0;y<h;y++) if (y&0x02) gdk_draw_point(draw_area->window,gc,cursor_x0,y);
    }
    if (cursor_y0<h)
    {
      for (int x=0;x<w;x++) if (x&0x02) gdk_draw_point(draw_area->window,gc,x,cursor_y0);
    }
    if (cursor_x1<w)
    {
      gdk_draw_line(draw_area->window,gc,cursor_x1,0,cursor_x1,h-1);
    }
    if (cursor_y0<h)
    {
      gdk_draw_line(draw_area->window,gc,0,cursor_y1,w-1,cursor_y1);
    }
    // Info labels
    if ((h>0) && (w>0))
    {
      std::string xtext;
      // 48 Pixel = eine Maßeinheit
      xtext=" X=" + pad(val2str((fabs(cursor_x1-cursor_x0)/48*Ttime[buf_time]),"S"),7);//+" ";
        
      if (fabs(cursor_x1-cursor_x0)>0)
      {
        xtext+=" f="+pad(val2str(1/(fabs(cursor_x1-cursor_x0)/48*Ttime[buf_time]),"Hz"),8);//+" ";
      }
      
      gtk_label_set_markup(GTK_LABEL(x_info_label),("<tt>"+xtext+"</tt>").c_str());
      std::string ytext;
      if (ui_ch1_on) ytext+=" Y(CH1)="+pad(val2str((ch1_k*(cursor_y0-cursor_y1)*8*VOLTAGE_RESOLUTION[buf_ch1])/(h),"V"),7);//+" ";
      if (ui_ch2_on) ytext+=" Y(CH2)="+pad(val2str((ch2_k*(cursor_y0-cursor_y1)*8*VOLTAGE_RESOLUTION[buf_ch2])/(h),"V"),7);//+" ";
      gtk_label_set_markup(GTK_LABEL(y_info_label),("<tt>"+ytext+"</tt>").c_str());
      gtk_widget_show(x_info_label);
      gtk_widget_show(y_info_label);
      //gtk_widget_hide(math_label);
    }
  }
  g_object_unref(gc);
  return TRUE;
}

gboolean on_hscale_changed (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  tr_pos = gtk_range_get_value(GTK_RANGE(hscale));

  return TRUE;
}

gboolean on_hscale1_changed (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  tr_pos1 = gtk_range_get_value(GTK_RANGE(hscale1));

  return TRUE;
}

gboolean on_vscale_changed (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  s_ch1_pos = gtk_range_get_value(GTK_RANGE(vscale));
  float xxx = s_ch1_pos;
  int a = round(xxx / 188 * 10);
  ch1_pos = xxx - a;
  return TRUE;
}

gboolean on_vscale1_changed (GtkWidget *widget, GdkEventExpose *event, gpointer data)
{
  s_ch2_pos = gtk_range_get_value(GTK_RANGE(vscale1));
  float xxx = s_ch2_pos;
  int a = round((xxx / 188) * 10);
  ch2_pos = xxx - a;
  return TRUE;
}

gboolean refresh_timer(gpointer data)
{
  if (buf_ready)
  {
    // copy buffer and params
    for (int n=0;n<BUFSIZE;n++)
    {
      ch1buf[n]=usb_ch1buf[n];
      ch2buf[n]=usb_ch2buf[n];
    }
    buf_time=usb_buf_time;
    buf_ch1=usb_buf_ch1;
    buf_ch2=usb_buf_ch2;
    buf_ready=false;
    // change label text
    std::string ch1_text;
    std::string ch2_text;
    std::string time_text;
    std::string sample_text;
    //
    ch1_text=val2str(VOLTAGE_RESOLUTION[buf_ch1]*ch1_k,"V");
    ch2_text=val2str(VOLTAGE_RESOLUTION[buf_ch2]*ch2_k,"V");
    //time
    time_text = gtk_combo_box_get_active_text(GTK_COMBO_BOX(cb_time));
    //samplerate
    sample_text = Sample[gtk_combo_box_get_active(GTK_COMBO_BOX(cb_time))];
    //
    gtk_label_set_markup(GTK_LABEL(ch1_label),("<tt> "+ch1_text+" </tt>").c_str());
    gtk_label_set_markup(GTK_LABEL(ch2_label),("<tt> "+ch2_text+" </tt>").c_str());
    gtk_label_set_markup(GTK_LABEL(time_label),("<tt> "+time_text+" </tt>").c_str());
    gtk_label_set_markup(GTK_LABEL(sample_label),("<tt> "+sample_text+" </tt>").c_str());
    if (ui_ch1_on) gtk_widget_show(ch1_label);else gtk_widget_hide(ch1_label);
    if (ui_ch2_on) gtk_widget_show(ch2_label);else gtk_widget_hide(ch2_label);
    gtk_widget_show(time_label);
    gtk_widget_show(demo_label);
    if (scopestate!=OK) gtk_label_set_text(GTK_LABEL(demo_label), "DEMO"); else gtk_label_set_text(GTK_LABEL(demo_label), "ONLINE");
    //
    if (draw_area!=NULL) gtk_widget_queue_draw (draw_area);
  }
  return !destroying;
}

gboolean on_mode_auto(GtkWidget *widget, gpointer data)
{
  capture_mode=CM_AUTO;
  return TRUE;
}

gboolean on_mode_single(GtkWidget *widget, gpointer data)
{
  capture_mode=CM_SINGLE;
  return TRUE;
}

void setup_cb_time()
{
  int i=gtk_combo_box_get_active(GTK_COMBO_BOX(cb_time));
  gtk_list_store_clear(GTK_LIST_STORE(gtk_combo_box_get_model(GTK_COMBO_BOX(cb_time))));
  //
  for (int n=0;n<TCOUNT;n++)
  {
    gtk_combo_box_append_text(GTK_COMBO_BOX(cb_time),Stime[n]);
  }
  gtk_combo_box_set_active(GTK_COMBO_BOX(cb_time),i);
}

void setup_ch1_voltage()
{
  int i=gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_voltage));
  gtk_list_store_clear(GTK_LIST_STORE(gtk_combo_box_get_model(GTK_COMBO_BOX(ch1_voltage))));
  //
  for (int n=0;n<VCOUNT;n++)
  {
    gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_voltage),val2str(VOLTAGE_RESOLUTION[n]*ch1_k,"V").c_str());
  }
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch1_voltage),i);
}

void setup_ch2_voltage()
{
  int i=gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_voltage));
  gtk_list_store_clear(GTK_LIST_STORE(gtk_combo_box_get_model(GTK_COMBO_BOX(ch2_voltage))));
  //
  for (int n=0;n<VCOUNT;n++)
  {
    gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_voltage),val2str(VOLTAGE_RESOLUTION[n]*ch2_k,"V").c_str());
  }
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch2_voltage),i);
}

gboolean on_cb_time_change(GtkWidget *widget, gpointer data)
{
  ui_time=gtk_combo_box_get_active(GTK_COMBO_BOX(cb_time));
  restart_capture=true;
  return TRUE;
}

gboolean on_ch1_on_change(GtkWidget *widget, gpointer data)
{
  ui_ch1_on=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch1_on));
  if (draw_area!=NULL) gtk_widget_queue_draw (draw_area);
  return TRUE;
}

gboolean on_ch2_on_change(GtkWidget *widget, gpointer data)
{
  ui_ch2_on=gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ch2_on));
  if (draw_area!=NULL) gtk_widget_queue_draw (draw_area);
  return TRUE;
}

gboolean on_ch1_voltage_change(GtkWidget *widget, gpointer data)
{
  ui_ch1_voltage=gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_voltage));
  restart_capture=true;
  return TRUE;
}

gboolean on_ch2_voltage_change(GtkWidget *widget, gpointer data)
{
  ui_ch2_voltage=gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_voltage));
  restart_capture=true;
  return TRUE;
}

gboolean on_ch1_mode_change(GtkWidget *widget, gpointer data)
{
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_mode))==CHMODE_DC) ui_ch1_mode=CHMODE_DC;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_mode))==CHMODE_AC) ui_ch1_mode=CHMODE_AC;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_mode))==CHMODE_GND) ui_ch1_mode=CHMODE_GND;
  restart_capture=true;
  return TRUE;
}

gboolean on_ch2_mode_change(GtkWidget *widget, gpointer data)
{
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_mode))==CHMODE_DC) ui_ch2_mode=CHMODE_DC;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_mode))==CHMODE_AC) ui_ch2_mode=CHMODE_AC;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_mode))==CHMODE_GND) ui_ch2_mode=CHMODE_GND;
  restart_capture=true;
  return TRUE;
}

void refresh_ch_k()
{
  if (ui_ch1_mul==X1) ch1_k=1;
  if (ui_ch1_mul==X10) ch1_k=10;
  if (ui_ch1_mul==X100) ch1_k=100;
  //
  if (ui_ch2_mul==X1) ch2_k=1;
  if (ui_ch2_mul==X10) ch2_k=10;
  if (ui_ch2_mul==X100) ch2_k=100;
}

gboolean on_ch1_mul_change(GtkWidget *widget, gpointer data)
{
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_mul))==X1) ui_ch1_mul=X1;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_mul))==X10) ui_ch1_mul=X10;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch1_mul))==X100) ui_ch1_mul=X100;
  refresh_ch_k();
  setup_ch1_voltage();
  if (draw_area!=NULL) gtk_widget_queue_draw (draw_area);
  //show_math();
  return TRUE;
}

gboolean on_ch2_mul_change(GtkWidget *widget, gpointer data)
{
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_mul))==X1) ui_ch2_mul=X1;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_mul))==X10) ui_ch2_mul=X10;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(ch2_mul))==X100) ui_ch2_mul=X100;
  refresh_ch_k();
  setup_ch2_voltage();
  if (draw_area!=NULL) gtk_widget_queue_draw (draw_area);
  //show_math();
  return TRUE;
}

gboolean on_cb_trigger_change(GtkWidget *widget, gpointer data)
{
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(cb_trigger))==0) ui_trigger=TR_CH1;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(cb_trigger))==1) ui_trigger=TR_CH2;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(cb_trigger))==2) ui_trigger=TR_ALT;
  if (gtk_combo_box_get_active(GTK_COMBO_BOX(cb_trigger))==3) ui_trigger=TR_EXT;
  restart_capture=true;
  return TRUE;
}

gboolean on_cb_edge_change(GtkWidget *widget, gpointer data)
{
  ui_edge=gtk_combo_box_get_active(GTK_COMBO_BOX(cb_edge));
  restart_capture=true;
  return TRUE;
}

gboolean on_draw_area_click(GtkWidget *widget, GdkEventButton *event, gpointer data)
{
  int x=event->x;
  int y=event->y;
  if (event->type==GDK_BUTTON_PRESS)
  {
    cursor_x0=x;
    cursor_y0=y;
    cursor_x1=-1;
    cursor_y1=-1;
    gtk_widget_hide(x_info_label);
    gtk_widget_hide(y_info_label);
    //show_math();
  }
  else
  {
    cursor_x1=x;
    cursor_y1=y;
    if ((event->type==GDK_BUTTON_RELEASE) && (cursor_x1==cursor_x0) && (cursor_y1==cursor_y0))
    {
      cursor_x0=-1;
      cursor_y0=-1;
      cursor_x1=-1;
      cursor_y1=-1;
      gtk_widget_hide(x_info_label);
      gtk_widget_hide(y_info_label);
      //show_math();
    }
  }
  if (draw_area!=NULL) gtk_widget_queue_draw (draw_area);
  return TRUE;
}

void create_interface()
{
  // Window
  window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
  gtk_window_set_title (GTK_WINDOW (window),WINDOW_TITLE.c_str());
  gtk_window_set_position (GTK_WINDOW (window), GTK_WIN_POS_CENTER);
  gtk_window_set_default_size (GTK_WINDOW (window),624,480);
  //gtk_container_set_border_width(GTK_CONTAINER(window), 3);
  
    GdkGeometry hints;
    hints.min_width = 624;
    hints.max_width = 624;
    hints.min_height = 482;
    hints.max_height = 482;
    
  gtk_window_set_geometry_hints(GTK_WINDOW(window),window,&hints,(GdkWindowHints)(GDK_HINT_MIN_SIZE | GDK_HINT_MAX_SIZE));
  //
  GtkWidget *button;
  GtkWidget *label;
  // vbox1
  GtkWidget *align=gtk_alignment_new (0.5f,0,0,0);
  GtkWidget *align1=gtk_alignment_new (0.5f,0,0,0);
  GtkWidget *vbox1 = gtk_vbox_new (false, 0);
  GtkWidget *hbox0 = gtk_hbox_new (false, 0);
  GtkWidget *hbox00 = gtk_hbox_new (false, 0);
  gtk_container_add (GTK_CONTAINER (window), align);
  gtk_container_add (GTK_CONTAINER (align), vbox1);
  gtk_container_add (GTK_CONTAINER (vbox1), align1);
  gtk_container_add (GTK_CONTAINER (vbox1), hbox00);
  gtk_container_add (GTK_CONTAINER (align1), hbox0);
  gtk_container_set_border_width(GTK_CONTAINER(hbox0), 2);
  
  //DrawArea
  
  GdkColor color;
  
  vscale=gtk_vscale_new_with_range(-188,188,1);
  gtk_scale_set_draw_value (GTK_SCALE(vscale),false);
  gtk_range_set_value(GTK_RANGE(vscale),s_ch1_pos);
  gdk_color_parse ("#00FF00", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(vscale), GTK_STATE_NORMAL, &color);
  gtk_widget_modify_bg ( GTK_WIDGET(vscale), GTK_STATE_PRELIGHT, &color);
  gtk_container_add (GTK_CONTAINER (hbox0), vscale);
  g_signal_connect (G_OBJECT (vscale),"value-changed",G_CALLBACK (on_vscale_changed), NULL);
  
  draw_area = gtk_drawing_area_new ();
  gtk_container_add (GTK_CONTAINER (hbox0), draw_area);
  gtk_widget_set_usize (draw_area, 576, 384);
  
  g_signal_connect (G_OBJECT (draw_area), "expose_event", G_CALLBACK (on_draw_area_expose), NULL);
  g_signal_connect (G_OBJECT (draw_area), "configure_event", G_CALLBACK (on_draw_area_resize), NULL);
  gtk_widget_add_events(draw_area, GDK_BUTTON_PRESS_MASK);
  gtk_widget_add_events(draw_area, GDK_BUTTON_MOTION_MASK);
  gtk_widget_add_events(draw_area, GDK_BUTTON_RELEASE_MASK);
  g_signal_connect(G_OBJECT(draw_area), "button-press-event", G_CALLBACK(on_draw_area_click), NULL);
  g_signal_connect(G_OBJECT(draw_area), "button-release-event", G_CALLBACK(on_draw_area_click), NULL);
  g_signal_connect(G_OBJECT(draw_area), "motion-notify-event", G_CALLBACK(on_draw_area_click), NULL);
  
  vscale1=gtk_vscale_new_with_range(-188,188,1);
  gtk_scale_set_draw_value  (GTK_SCALE(vscale1),false);
  gtk_range_set_value(GTK_RANGE(vscale1),s_ch2_pos);
  gdk_color_parse ("#FFFF00", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(vscale1), GTK_STATE_NORMAL, &color);
  gtk_widget_modify_bg ( GTK_WIDGET(vscale1), GTK_STATE_PRELIGHT, &color);
  gtk_container_add (GTK_CONTAINER (hbox0), vscale1);
  g_signal_connect (G_OBJECT (vscale1),"value-changed",G_CALLBACK (on_vscale1_changed), NULL);
  // hbox1 for labels
  GtkWidget *ax1=gtk_alignment_new(0,0,0,0);
  gtk_alignment_set_padding(GTK_ALIGNMENT(ax1),2,2,20,0);
  GtkWidget *hbox1 = gtk_hbox_new (false, 0);
  gtk_container_add (GTK_CONTAINER (vbox1), ax1);
  gtk_container_add (GTK_CONTAINER (ax1), hbox1);
  // Labels
  // CH1
  PangoAttrList *ch1_alist = pango_attr_list_new ();
  PangoAttribute *attr;
  PangoFontDescription *df;
  df = pango_font_description_new ();
  pango_font_description_set_family(df,"Menlo");
  pango_font_description_set_size(df, 12 * PANGO_SCALE);
  attr = pango_attr_font_desc_new(df);
  pango_font_description_free(df);
  pango_attr_list_insert (ch1_alist, attr);
  attr = pango_attr_background_new(0x0000,0x0000,0x0000);
  pango_attr_list_insert (ch1_alist, attr);
  attr = pango_attr_foreground_new(0x0000,0xffff,0x0000);
  pango_attr_list_insert (ch1_alist, attr);
  //
  ch1_label = gtk_label_new (" CH1 ");
  gtk_misc_set_alignment (GTK_MISC (ch1_label), 0.0, 0.5);
  gtk_label_set_attributes (GTK_LABEL(ch1_label),ch1_alist);
  gtk_box_pack_start (GTK_BOX (hbox1), ch1_label, false, false, 2);
  // CH2
  PangoAttrList *ch2_alist = pango_attr_list_new ();
  df = pango_font_description_new ();
  pango_font_description_set_family(df,"Menlo");
  pango_font_description_set_size(df, 12 * PANGO_SCALE);
  attr = pango_attr_font_desc_new(df);
  pango_font_description_free(df);
  pango_attr_list_insert (ch2_alist, attr);
  attr = pango_attr_background_new(0x0000,0x0000,0x0000);
  pango_attr_list_insert (ch2_alist, attr);
  attr = pango_attr_foreground_new(0xffff,0xffff,0x0000);
  pango_attr_list_insert (ch2_alist, attr);
  //
  ch2_label = gtk_label_new (" CH2 ");
  gtk_misc_set_alignment (GTK_MISC (ch2_label), 0.0, 0.5);
  gtk_label_set_attributes (GTK_LABEL(ch2_label),ch2_alist);
  gtk_box_pack_start (GTK_BOX (hbox1), ch2_label, false, false, 2);
  // TIME
  PangoAttrList *time_alist = pango_attr_list_new ();
  df = pango_font_description_new ();
  pango_font_description_set_family(df,"Menlo");
  pango_font_description_set_size(df, 12 * PANGO_SCALE);
  attr = pango_attr_font_desc_new(df);
  pango_font_description_free(df);
  pango_attr_list_insert (time_alist, attr);
  attr = pango_attr_background_new(0x0000,0x0000,0x0000);
  pango_attr_list_insert (time_alist, attr);
  attr = pango_attr_foreground_new(0xc000,0xc000,0xff00);
  pango_attr_list_insert (time_alist, attr);
  //
  time_label = gtk_label_new (" TIME ");
  gtk_misc_set_alignment (GTK_MISC (time_label), 0.0, 0.5);
  gtk_label_set_attributes (GTK_LABEL(time_label),time_alist);
  gtk_box_pack_start (GTK_BOX (hbox1),time_label, false, false, 2);
  //
  sample_label = gtk_label_new (" SAMPLE ");
  gtk_misc_set_alignment (GTK_MISC (time_label), 0.0, 0.5);
  gtk_label_set_attributes (GTK_LABEL(sample_label),time_alist);
  gtk_box_pack_start (GTK_BOX (hbox1),sample_label, false, false, 2);
  // CURSOR X INFO
  PangoAttrList *x_info_alist = pango_attr_list_new ();
  df = pango_font_description_new ();
  pango_font_description_set_family(df,"Menlo");
  pango_font_description_set_size(df, 12 * PANGO_SCALE);
  attr = pango_attr_font_desc_new(df);
  pango_font_description_free(df);
  pango_attr_list_insert (x_info_alist, attr);
  attr = pango_attr_background_new(0x0000,0x0000,0x0000);
  pango_attr_list_insert (x_info_alist, attr);
  attr = pango_attr_foreground_new(0xffff,0x8000,0xffff);
  pango_attr_list_insert (x_info_alist, attr);
  //
  x_info_label = gtk_label_new (" X INFO ");
  gtk_misc_set_alignment (GTK_MISC (x_info_label), 0.0, 0.5);
  gtk_label_set_attributes (GTK_LABEL(x_info_label),x_info_alist);
  gtk_box_pack_start (GTK_BOX (hbox1),x_info_label, false, false, 2);
  // CURSOR Y INFO
  PangoAttrList *y_info_alist = pango_attr_list_new ();
  df = pango_font_description_new ();
  pango_font_description_set_family(df,"Menlo");
  pango_font_description_set_size(df, 12 * PANGO_SCALE);
  attr = pango_attr_font_desc_new(df);
  pango_font_description_free(df);
  pango_attr_list_insert (y_info_alist, attr);
  attr = pango_attr_background_new(0x0000,0x0000,0x0000);
  pango_attr_list_insert (y_info_alist, attr);
  attr = pango_attr_foreground_new(0xffff,0x8000,0xffff);
  pango_attr_list_insert (y_info_alist, attr);
  //
  y_info_label = gtk_label_new (" Y INFO ");
  gtk_misc_set_alignment (GTK_MISC (y_info_label), 0.0, 0.5);
  gtk_label_set_attributes (GTK_LABEL(y_info_label),y_info_alist);
  gtk_box_pack_start (GTK_BOX (hbox1),y_info_label, false, false, 2);
  // hbox2 for scope control
  GtkWidget *ax2=gtk_alignment_new(0.5,0,0,0);
  gtk_alignment_set_padding(GTK_ALIGNMENT(ax2),3,3,3,3);
  GtkWidget *hbox2 = gtk_hbox_new (false, 0);
  gtk_container_add (GTK_CONTAINER (vbox1), ax2);
  gtk_container_add (GTK_CONTAINER (ax2), hbox2);
  // CH1 control
  GtkWidget *frame3 = gtk_frame_new("CH1");
  gtk_frame_set_shadow_type(GTK_FRAME(frame3), GTK_SHADOW_ETCHED_IN);
  gdk_color_parse ("#66FF66", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(frame3), GTK_STATE_NORMAL, &color);
  gtk_box_pack_start (GTK_BOX (hbox2),frame3, false, false,2);
  //
  GtkWidget *a1=gtk_alignment_new(0,0,0,0);
  gtk_alignment_set_padding(GTK_ALIGNMENT(a1),0,2,3,3);
  gtk_container_add (GTK_CONTAINER (frame3), a1);
  //
  GtkWidget *hbox_4 = gtk_hbox_new (false, 3);
  GtkWidget *vbox4 = gtk_vbox_new (false, 3);
  GtkWidget *vbox4a = gtk_vbox_new (false, 3);
  gtk_container_add (GTK_CONTAINER (a1), hbox_4);
  gtk_container_add (GTK_CONTAINER (hbox_4), vbox4);
  gtk_container_add (GTK_CONTAINER (hbox_4), vbox4a);
  //
  ch1_on=gtk_check_button_new_with_label("On");
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch1_on),ui_ch1_on);
  g_signal_connect (G_OBJECT (ch1_on),"toggled",G_CALLBACK (on_ch1_on_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox4),ch1_on, false, false,2);
  //
  ch1_voltage=gtk_combo_box_new_text();
  setup_ch1_voltage();
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch1_voltage),ui_ch1_voltage);
  g_signal_connect (G_OBJECT (ch1_voltage),"changed",G_CALLBACK (on_ch1_voltage_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox4),ch1_voltage, false, false, 1);
  //on_cb_math_change
  ch1_mode=gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_mode),"DC");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_mode),"AC");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_mode),"GND");
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch1_mode),ui_ch1_mode);
  g_signal_connect (G_OBJECT (ch1_mode),"changed",G_CALLBACK (on_ch1_mode_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox4a),ch1_mode, false, false, 2);
  //
  ch1_mul=gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_mul),"X1");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_mul),"X10");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch1_mul),"X100");
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch1_mul),ui_ch1_mul);
  g_signal_connect (G_OBJECT (ch1_mul),"changed",G_CALLBACK (on_ch1_mul_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox4a),ch1_mul, false, false, 0);
  // CH2 control
  GtkWidget *frame4 = gtk_frame_new("CH2");
  gtk_frame_set_shadow_type(GTK_FRAME(frame4), GTK_SHADOW_ETCHED_IN);
  gdk_color_parse ("#FFFF00", &color);
  gtk_widget_modify_bg (GTK_WIDGET(frame4), GTK_STATE_NORMAL, &color);
  gtk_box_pack_start (GTK_BOX (hbox2),frame4, false, false,2);
  //
  GtkWidget *a2=gtk_alignment_new(0,0,0,0);
  gtk_alignment_set_padding(GTK_ALIGNMENT(a2),0,2,3,3);
  gtk_container_add (GTK_CONTAINER (frame4), a2);
  //
  GtkWidget *hbox_5 = gtk_hbox_new (false, 3);
  GtkWidget *vbox5 = gtk_vbox_new (false, 3);
  GtkWidget *vbox5a = gtk_vbox_new (false, 3);
  gtk_container_add (GTK_CONTAINER (a2), hbox_5);
  gtk_container_add (GTK_CONTAINER (hbox_5), vbox5);
  gtk_container_add (GTK_CONTAINER (hbox_5), vbox5a);
  //
  ch2_on=gtk_check_button_new_with_label("On");
  gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ch2_on),ui_ch2_on);
  g_signal_connect (G_OBJECT (ch2_on),"toggled",G_CALLBACK (on_ch2_on_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox5),ch2_on, false, false,2);
  //
  ch2_voltage=gtk_combo_box_new_text();
  setup_ch2_voltage();
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch2_voltage),ui_ch2_voltage);
  g_signal_connect (G_OBJECT (ch2_voltage),"changed",G_CALLBACK (on_ch2_voltage_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox5),ch2_voltage, false, false, 1);
  //
  ch2_mode=gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_mode),"DC");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_mode),"AC");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_mode),"GND");
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch2_mode),ui_ch2_mode);
  g_signal_connect (G_OBJECT (ch2_mode),"changed",G_CALLBACK (on_ch2_mode_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox5a),ch2_mode, false, false, 2);
  //
  ch2_mul=gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_mul),"X1");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_mul),"X10");
  gtk_combo_box_append_text(GTK_COMBO_BOX(ch2_mul),"X100");
  gtk_combo_box_set_active(GTK_COMBO_BOX(ch2_mul),ui_ch2_mul);
  g_signal_connect (G_OBJECT (ch2_mul),"changed",G_CALLBACK (on_ch2_mul_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox5a),ch2_mul, false, false, 0);
  //
  GtkWidget *vbox8 = gtk_vbox_new(false,5);
  gtk_box_pack_start (GTK_BOX(hbox2),vbox8,false,false,3);
  // Time control
  GtkWidget *frame2 = gtk_frame_new("Time/Div.");
  gdk_color_parse ("#FF99FF", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(frame2), GTK_STATE_NORMAL, &color);
  gtk_frame_set_shadow_type(GTK_FRAME(frame2), GTK_SHADOW_ETCHED_IN);
  gtk_box_pack_start (GTK_BOX (vbox8),frame2, false, false,0);
  //
  GtkWidget *a3=gtk_alignment_new(0.5,0,0,0);
  gtk_alignment_set_padding(GTK_ALIGNMENT(a3),0,2,3,3);
  gtk_container_add (GTK_CONTAINER (frame2), a3);
  //
  GtkWidget *vbox3 = gtk_vbox_new (false, 0);
  gtk_container_add (GTK_CONTAINER (a3), vbox3);
  //
  cb_time=gtk_combo_box_new_text();
  setup_cb_time();
  gtk_combo_box_set_active(GTK_COMBO_BOX(cb_time),ui_time);
  g_signal_connect (G_OBJECT (cb_time),"changed",G_CALLBACK (on_cb_time_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox3),cb_time, false, true, 2);
  // Demo label
  demo_label = gtk_label_new ("- DEMO -");
  gtk_misc_set_alignment (GTK_MISC (demo_label), 0.5, 0.5);
  gtk_misc_set_padding (GTK_MISC (demo_label), 5, 0);
  gtk_box_pack_start (GTK_BOX (vbox8),demo_label, false, false, 2);
  
  // Mode control
  GtkWidget *frame1 = gtk_frame_new("Trigger");
  gdk_color_parse ("#66FFFF", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(frame1), GTK_STATE_NORMAL, &color);
  gtk_frame_set_shadow_type(GTK_FRAME(frame1), GTK_SHADOW_ETCHED_IN);
  gtk_box_pack_start (GTK_BOX (hbox2),frame1, false, false,2);
  //
  GtkWidget *a4=gtk_alignment_new(0,0,0,0);
  gtk_alignment_set_padding(GTK_ALIGNMENT(a4),0,2,3,3);
  gtk_container_add (GTK_CONTAINER (frame1), a4);
  //
  GtkWidget *hbox_x2 = gtk_hbox_new (false, 3);
  GtkWidget *vbox2 = gtk_vbox_new (false, 3);
  GtkWidget *vbox2a = gtk_vbox_new (false, 3);
  GtkWidget *vbox2b = gtk_vbox_new (false, 3);
  gtk_container_add (GTK_CONTAINER (a4), hbox_x2);
  gtk_container_add (GTK_CONTAINER (hbox_x2), vbox2);
  gtk_container_add (GTK_CONTAINER (hbox_x2), vbox2a);
  gtk_container_add (GTK_CONTAINER (hbox_x2), vbox2b);
  //
  button = gtk_button_new_with_label ("Auto");
  gtk_widget_set_usize(GTK_WIDGET(button),60,22);
  g_signal_connect (G_OBJECT (button),"clicked",G_CALLBACK (on_mode_auto), NULL);
  gtk_box_pack_start (GTK_BOX (vbox2), button, false, false, 2);
  //
  button = gtk_button_new_with_label ("Single");
  gtk_widget_set_usize(GTK_WIDGET(button),60,22);
  g_signal_connect (G_OBJECT (button),"clicked",G_CALLBACK (on_mode_single), NULL);
  gtk_box_pack_start (GTK_BOX (vbox2), button, false, false, 0);
  //
  cb_trigger=gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(cb_trigger),"CH1");
  gtk_combo_box_append_text(GTK_COMBO_BOX(cb_trigger),"CH2");
  gtk_combo_box_append_text(GTK_COMBO_BOX(cb_trigger),"ALT");
  gtk_combo_box_append_text(GTK_COMBO_BOX(cb_trigger),"EXT");
  gtk_combo_box_set_active(GTK_COMBO_BOX(cb_trigger),ui_trigger);
  g_signal_connect (G_OBJECT (cb_trigger),"changed",G_CALLBACK (on_cb_trigger_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox2a),cb_trigger, false, false, 2);
  //
  cb_edge=gtk_combo_box_new_text();
  gtk_combo_box_append_text(GTK_COMBO_BOX(cb_edge),"+");
  gtk_combo_box_append_text(GTK_COMBO_BOX(cb_edge),"-");
  gtk_combo_box_set_active(GTK_COMBO_BOX(cb_edge),ui_edge);
  g_signal_connect (G_OBJECT (cb_edge),"changed",G_CALLBACK (on_cb_edge_change), NULL);
  gtk_box_pack_start (GTK_BOX (vbox2a),cb_edge, false, false, 0);
  //
  hscale=gtk_hscale_new_with_range(77,177,1);
  gtk_scale_set_draw_value (GTK_SCALE(hscale),false);
  gtk_widget_set_size_request (hscale, 104,15);
  gtk_range_set_value(GTK_RANGE(hscale),127);
  //gtk_scale_add_mark (GTK_SCALE(hscale),77, GTK_POS_BOTTOM, NULL);
  //gtk_scale_add_mark (GTK_SCALE(hscale),127, GTK_POS_BOTTOM, NULL);
  //gtk_scale_add_mark (GTK_SCALE(hscale),177, GTK_POS_BOTTOM, NULL);
  gdk_color_parse ("#00FF00", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(hscale), GTK_STATE_NORMAL, &color);
  gtk_widget_modify_bg ( GTK_WIDGET(hscale), GTK_STATE_PRELIGHT, &color);
  g_signal_connect (G_OBJECT (hscale),"value-changed",G_CALLBACK (on_hscale_changed), NULL);
  gtk_box_pack_start (GTK_BOX (vbox2b), hscale, true, true, 3);
  //
  hscale1=gtk_hscale_new_with_range(77,177,1);
  gtk_scale_set_draw_value (GTK_SCALE(hscale1),false);
  gtk_widget_set_size_request (hscale1, 104,15);
  gtk_range_set_value(GTK_RANGE(hscale1),127);
  //gtk_scale_add_mark (GTK_SCALE(hscale1),77, GTK_POS_TOP, NULL);
  //gtk_scale_add_mark (GTK_SCALE(hscale1),127, GTK_POS_TOP, NULL);
  //gtk_scale_add_mark (GTK_SCALE(hscale1),177, GTK_POS_TOP, NULL);
  gdk_color_parse ("#FFFF00", &color);
  gtk_widget_modify_bg ( GTK_WIDGET(hscale1), GTK_STATE_NORMAL, &color);
  gtk_widget_modify_bg ( GTK_WIDGET(hscale1), GTK_STATE_PRELIGHT, &color);
  g_signal_connect (G_OBJECT (hscale1),"value-changed",G_CALLBACK (on_hscale1_changed), NULL);
  gtk_box_pack_start (GTK_BOX (vbox2b), hscale1, true, true, 0);
  //
  g_timeout_add(20,refresh_timer,NULL);
}


